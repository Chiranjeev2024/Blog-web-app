import Home from "./Home";
import PostDetail from "./PostDetails";
import CreatePost from "./CreatePost";
import Navbar from "./Navbar";

export { Home, PostDetail, CreatePost, Navbar };
