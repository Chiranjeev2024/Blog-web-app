function PostDetail() {
  return <div className="PostDetail">Post Detail</div>;
}

export default PostDetail;
