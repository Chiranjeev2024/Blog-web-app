function Button(props) {
  return (
    <div className={props.buttonTitle} onClick={props.onClick}>
      {props.buttonTitle}
    </div>
  );
}
export default Button;
