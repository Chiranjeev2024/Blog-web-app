function Post(props) {
  return <div className="post">{props.postTitle}</div>;
}

export default Post;
